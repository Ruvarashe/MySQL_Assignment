<?php
	include_once('connect.php');
	$queryString='
	CREATE TABLE Patients_Info
	(
		Title varchar(5),
		Name varchar(10),
		Surname varchar(14),
		Gender varchar(8),
		Phone varchar(14) PRIMARY KEY,
		Citizenship varchar(15),
		Email varchar(20),
		Appointment_Date varchar(15),
		Appointment_Time varchar(15)

	);
';

	if($Clinic_conn->query($queryString)){
		echo "Table created successfully";
	}



?>