<!Doctype html>
	<html>
		<head>
			<title></title>
		</head>
		<body>
			<?php
				
				if ($_POST ['username']=='tecla' && $_POST['password']=='1234'){
			?>
			<a href="profiles.php?username=<?php echo $_POST['username'] ?>">
			Go to profile Page
			</a>

			<?php
			} else {
			?>

				<a href="Appointment.php.html">Log in failure go to Home</a> 
             <?php
			}
			?>	
		
				
		</body>
	</html>