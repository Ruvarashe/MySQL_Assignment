!UNDP CLINIC>
<html>
	<head>
		<title></title>

	</head>
	<body>
		<form action="loged.php" method="post">
			<label for="username">Username:</label>
			<input type="text" name="username"> </input>

			<label for="password">Password:</label>
			<input type="password" name="password"> </input>

			<input type="submit" value="Log in"></input>


		</form>
	</body>
</html>