<?php
$Clinic_conn=new mysqli('localhost','Clinic_user','1234','Clinic_db');
  if($Clinic_conn->connect_errno){
	  
	  echo "Error".$Clinic_conn->connect_errno." has occured";
	  
  }else{
	  echo "you are connected";
	
  }
	
?>

