
<?php
 include_once("connect.php");
 $title=$_POST["title"];
 $Name =$_POST["username"];
 $surname=$_POST["surname"];
 $gender =$_POST["Gender"];
 $phoneNumber =$_POST["phone_number"];
 $citizenship=$_POST["citizenship"];
 $appointedTime=$_POST["appointment_time"];
 $appointedDate=$_POST["appointment_date"];

echo "$title,$Name,$surname,$gender,$phoneNumber,$citizenship,$appointedTime,$appointedDate";


	$query_string="
	INSERT INTO Students(title,Name,surname,gender,phoneNumber,citizenship,appointedTime, appointedDate)
	VALUES($title,$Name,$surname,$gender,$phoneNumber,$citizenship,$appointedTime,$appointedDate);
	
	";
	if($Clinic_conn->query($query_string)){
		echo "inserted";
	}
	else {
		echo"Insert failed";
	}
	header("refresh:2; url=Appointment.php")
?>
<!doctype html>
<html>
<head>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>

</body>
</html>





